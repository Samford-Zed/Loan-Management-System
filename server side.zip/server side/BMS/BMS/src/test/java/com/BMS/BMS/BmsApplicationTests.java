package com.BMS.BMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
