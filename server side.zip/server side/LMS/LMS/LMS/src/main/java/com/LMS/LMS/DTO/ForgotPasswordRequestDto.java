package com.LMS.LMS.DTO;


public record ForgotPasswordRequestDto(String email) {}
